-- FinTech Monitoring System Database Schema
-- PostgreSQL 15

-- Create database (if running manually)
-- CREATE DATABASE fintech_db;
-- \c fintech_db

-- Market Data Table
CREATE TABLE IF NOT EXISTS market_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    price DECIMAL(10, 2),
    change_amount DECIMAL(10, 2),
    change_percent DECIMAL(5, 2),
    volume BIGINT,
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_market_symbol_time ON market_data(symbol, timestamp DESC);

-- News Articles Table
CREATE TABLE IF NOT EXISTS news_articles (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    content TEXT,
    source VARCHAR(255),
    url TEXT UNIQUE,
    published_at TIMESTAMP,
    fetched_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_news_symbol ON news_articles(symbol, published_at DESC);
CREATE INDEX idx_news_url ON news_articles(url);

-- Sentiment Analysis Table
CREATE TABLE IF NOT EXISTS sentiment_analysis (
    id SERIAL PRIMARY KEY,
    article_id INTEGER REFERENCES news_articles(id) ON DELETE CASCADE,
    symbol VARCHAR(10) NOT NULL,
    sentiment_score DECIMAL(5, 4),
    sentiment_label VARCHAR(20),
    confidence DECIMAL(5, 4),
    key_points TEXT[],
    market_impact VARCHAR(20),
    summary TEXT,
    analyzed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sentiment_symbol ON sentiment_analysis(symbol, analyzed_at DESC);
CREATE INDEX idx_sentiment_article ON sentiment_analysis(article_id);

-- Trading Signals Table
CREATE TABLE IF NOT EXISTS trading_signals (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    signal VARCHAR(20) NOT NULL,
    composite_score DECIMAL(5, 4),
    price_change DECIMAL(5, 2),
    sentiment_score DECIMAL(5, 4),
    confidence DECIMAL(5, 4),
    reason TEXT,
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_signals_symbol ON trading_signals(symbol, timestamp DESC);

-- Alerts Table
CREATE TABLE IF NOT EXISTS alerts (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    details JSONB,
    triggered BOOLEAN DEFAULT TRUE,
    email_sent BOOLEAN DEFAULT FALSE,
    sms_sent BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_alerts_symbol ON alerts(symbol, timestamp DESC);
CREATE INDEX idx_alerts_triggered ON alerts(triggered, timestamp DESC);
CREATE INDEX idx_alerts_type ON alerts(alert_type);

-- Create views for common queries

-- Latest market data per symbol
CREATE OR REPLACE VIEW v_latest_market_data AS
SELECT DISTINCT ON (symbol) 
    symbol, price, change_amount, change_percent, volume, timestamp
FROM market_data
ORDER BY symbol, timestamp DESC;

-- Sentiment summary by symbol (last 24 hours)
CREATE OR REPLACE VIEW v_sentiment_summary_24h AS
SELECT 
    symbol,
    COUNT(*) as article_count,
    AVG(sentiment_score) as avg_sentiment,
    AVG(confidence) as avg_confidence,
    MAX(analyzed_at) as last_analysis
FROM sentiment_analysis
WHERE analyzed_at > NOW() - INTERVAL '24 hours'
GROUP BY symbol;

-- Recent high-priority alerts
CREATE OR REPLACE VIEW v_recent_high_priority_alerts AS
SELECT 
    symbol, alert_type, severity, message, timestamp
FROM alerts
WHERE severity = 'HIGH' 
  AND timestamp > NOW() - INTERVAL '24 hours'
ORDER BY timestamp DESC;

-- Grant permissions (adjust as needed for your setup)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO fintech_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO fintech_user;

-- Insert some sample data for testing (optional)
-- INSERT INTO market_data (symbol, price, change_amount, change_percent, volume, timestamp)
-- VALUES ('AAPL', 175.50, 2.50, 1.45, 50000000, NOW());

COMMENT ON TABLE market_data IS 'Real-time market data from Alpha Vantage API';
COMMENT ON TABLE news_articles IS 'Financial news from NewsAPI';
COMMENT ON TABLE sentiment_analysis IS 'AI-powered sentiment analysis using Google Gemini';
COMMENT ON TABLE trading_signals IS 'Composite trading signals from multiple sources';
COMMENT ON TABLE alerts IS 'System-generated alerts for significant events';
