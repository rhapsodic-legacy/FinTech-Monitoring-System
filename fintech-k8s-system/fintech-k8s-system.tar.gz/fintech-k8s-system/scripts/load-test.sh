#!/bin/bash

# Load Testing Script for FinTech K8s System
# This script generates load to test the HorizontalPodAutoscaler

echo "🔥 Starting Load Test for Analyzer Service"
echo "==========================================="

# Check if Apache Bench is installed
if ! command -v ab &> /dev/null; then
    echo "Apache Bench (ab) not found. Installing..."
    
    # macOS
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "Apache Bench should be pre-installed on macOS"
        echo "If not, install with: brew install httpd"
    # Linux
    else
        sudo apt-get update && sudo apt-get install -y apache2-utils
    fi
fi

# Port forward to analyzer service
echo "Setting up port forward to analyzer service..."
kubectl port-forward -n fintech svc/analyzer-service 5001:5001 &
PF_PID=$!

# Wait for port forward to be ready
sleep 3

echo ""
echo "Generating load on analyzer service..."
echo "This will help trigger the HorizontalPodAutoscaler"
echo ""

# Run load test
# 10000 requests, 100 concurrent
ab -n 10000 -c 100 http://localhost:5001/health

echo ""
echo "Load test complete!"
echo ""
echo "Check HPA status with:"
echo "  kubectl get hpa -n fintech"
echo ""
echo "Watch pods scaling:"
echo "  kubectl get pods -n fintech -w"

# Kill port forward
kill $PF_PID 2>/dev/null

echo ""
echo "To see pod metrics:"
echo "  kubectl top pods -n fintech"
